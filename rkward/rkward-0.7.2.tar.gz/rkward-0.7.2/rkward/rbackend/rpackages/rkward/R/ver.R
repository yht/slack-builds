# DO NOT CHANGE THIS FILE MANUALLY!
# version number will be updated by cmake, see
# rkward/SetVersionNumber.cmake

#' @export
".rk.app.version" <- "0.7.2"
