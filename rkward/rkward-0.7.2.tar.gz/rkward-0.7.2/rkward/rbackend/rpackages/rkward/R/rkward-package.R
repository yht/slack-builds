#' \packageDescription{rkward}
#'
#' The DESCRIPTION file:
#' \tabular{ll}{
#' Package: \tab rkward\cr
#' Type: \tab Package\cr
#' Version: \tab 0.7.1\cr
#' Date: \tab 2018-10-11\cr
#' Depends: \tab R (>= 2.9.0),methods\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 2)\cr
#' LazyLoad: \tab yes\cr
#' URL: \tab https://rkward.kde.org\cr
#' }
#'
#' @title
#' \packageTitle{rkward}
#' @author
#' \packageAuthor{rkward}
#'
#' Maintainer: \packageMaintainer{rkward}
"_PACKAGE"
