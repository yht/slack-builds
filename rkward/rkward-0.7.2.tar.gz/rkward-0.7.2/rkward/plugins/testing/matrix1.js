function calculate () {
	echo ("Matrix A:\n");
	echo (getValue ("matrixa.cbind"));
	echo ("\nMatrix B:\n");
	echo (getValue ("matrixb.cbind"));
	echo ("\nMatrix C:\n");
	echo (getValue ("matrixc.cbind"));
	echo ("\nMatrix C, column 2:\n");
	echo (getValue ("matrixc.2"));
}

