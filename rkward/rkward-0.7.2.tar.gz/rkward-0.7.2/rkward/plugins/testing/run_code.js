function calculate () {
	echo (getValue ('codetorun.text')+'\n');
}
