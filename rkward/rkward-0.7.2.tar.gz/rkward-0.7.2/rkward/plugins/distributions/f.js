include ("dist_common.js");

function getDistSpecifics () {
	return initDistSpecifics (i18n ('F distribution'), 'f', ["df1", "df2", "ncp"], [0, undefined], continuous);
}
