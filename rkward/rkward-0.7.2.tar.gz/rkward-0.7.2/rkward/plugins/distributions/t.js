include ("dist_common.js");

function getDistSpecifics () {
	return initDistSpecifics (i18n ('t distribution'), 't', ["df", "ncp"], [], continuous);
}
