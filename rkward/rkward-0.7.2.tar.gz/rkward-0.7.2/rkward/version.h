/* Version number of package */
#define RKWARD_VERSION "0.7.2"
